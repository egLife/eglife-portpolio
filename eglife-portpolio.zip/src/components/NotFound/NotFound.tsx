import * as React from 'react';

class NotFound extends React.Component<{}, {}> {
    render() {
        return (
            <></>
        );
    }
}

export default NotFound;
