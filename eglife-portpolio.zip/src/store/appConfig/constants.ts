// ====================== CONFIG CONSTANT ======================

// ====================== CSS
export const CONFIG_INIT_CSS_ALL = '@app/config/initCSSAll';
export const CONFIG_UPDATE_CSS_COMPONENT_BG_COLOR = '@app/config/updatecomponentTemaColor';
export const CONFIG_UPDATE_CSS_COMPONENT_TEXT_COLOR = '@app/config/updateComponentTextColor';
export const CONFIG_UPDATE_CSS_COMPONENT_TITLE_COLOR = '@app/config/updateComponentTitleColor';

// ====================== STATUS
export const CONFIG_INIT_STATUS_ALL = '@app/config/initStatusAll';
export const CONFIG_UPDATE_STATUS_IS_SHOW_MAIN = '@app/config/updateIsShowMain';
export const CONFIG_UPDATE_STATUS_PAGE_NUM =  '@app/config/updatePageNum';
