export default {
    MAIN: {
        TITLE_1: '안녕하세요. 저는  ',
        TITLE_2: '"신은규"',
        TITLE_3: '입니다.',
        TITLE: '안녕하세요. 저는 "신은규" 입니다.',
        SUB_TITLE: 'FRONT-END DEVELOPER',
        BUTTON: 'VIEW DETAIL'
    }
};