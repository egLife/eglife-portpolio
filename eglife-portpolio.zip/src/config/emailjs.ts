export default {
    user_id: 'user_W4ws8q8Ojz6xVCnNplYZ6',
    service_id: 'tlsdmsrb0427',
    template_id: 'tlsdmsrb0427_template'
};