declare module 'case-sensitive-paths-webpack-plugin';
declare module 'progress-bar-webpack-plugin';
declare module 'terser-webpack-plugin';
declare module 'webpack-dashboard';
declare module 'webpack-dashboard/plugin';
declare module 'webpack-md5-hash';
declare module 'emailjs-com';
